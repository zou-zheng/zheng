package com.minghui.learning;

import android.content.Context;
import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.media.AudioAttributes;
import android.os.Handler;
import android.os.Looper;
import android.speech.tts.TextToSpeech;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

import java.util.Locale;

public final class AnalyticsBridge {
    private final AnalyticsDbHelper helper;
    private final TextToSpeech textToSpeech;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private volatile boolean textToSpeechReady = false;
    private volatile boolean textToSpeechFailed = false;
    private String pendingText;
    private String pendingLanguage;
    private float pendingRate;

    public AnalyticsBridge(Context context, AnalyticsDbHelper helper) {
        this.helper = helper;
        textToSpeech = new TextToSpeech(context.getApplicationContext(), status -> {
            textToSpeechReady = status == TextToSpeech.SUCCESS;
            textToSpeechFailed = !textToSpeechReady;
            if (textToSpeechReady && pendingText != null) {
                String text = pendingText;
                String language = pendingLanguage;
                float rate = pendingRate;
                pendingText = null;
                pendingLanguage = null;
                speakNow(text, language, rate);
            }
        });
    }

    @JavascriptInterface
    public void recordEvent(String rawPayload) {
        try {
            JSONObject payload = new JSONObject(rawPayload);
            String userId = payload.optString("userId", "");
            String eventName = payload.optString("eventName", "");
            if (!userId.matches("[A-Za-z0-9_-]{1,80}") || !eventName.matches("[A-Za-z0-9_.:-]{1,80}")) {
                return;
            }

            JSONObject metadata = payload.optJSONObject("metadata");
            String metadataJson = metadata == null ? "{}" : metadata.toString();
            if (metadataJson.length() > 2000) metadataJson = metadataJson.substring(0, 2000);

            ContentValues values = new ContentValues();
            values.put("user_id", userId);
            values.put("event_name", eventName);
            values.put("page", limit(payload.optString("page", ""), 40));
            values.put("subject_id", limit(payload.optString("subjectId", ""), 40));
            values.put("grade", limit(payload.optString("grade", ""), 20));
            values.put("semester", limit(payload.optString("semester", ""), 20));
            values.put("textbook", limit(payload.optString("textbook", ""), 40));
            values.put("metadata_json", metadataJson);
            SQLiteDatabase database = helper.getWritableDatabase();
            database.insert("user_events", null, values);
        } catch (Exception ignored) {
            // 埋点不能影响学习页面正常使用。
        }
    }

    @JavascriptInterface
    public void speakText(String text, String language, float rate) {
        if (text == null || text.trim().isEmpty()) return;
        String requestedLanguage = language == null || language.trim().isEmpty() ? "en-US" : language;
        float requestedRate = Math.max(0.35f, Math.min(1.5f, rate <= 0 ? 0.82f : rate));
        mainHandler.post(() -> {
            if (textToSpeechReady) {
                speakNow(text, requestedLanguage, requestedRate);
            } else if (!textToSpeechFailed) {
                pendingText = text;
                pendingLanguage = requestedLanguage;
                pendingRate = requestedRate;
            }
        });
    }

    private void speakNow(String text, String language, float rate) {
        textToSpeech.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        Locale locale = Locale.forLanguageTag(language.replace('_', '-'));
        int languageResult = textToSpeech.setLanguage(locale);
        if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) {
            languageResult = textToSpeech.setLanguage(Locale.US);
        }
        if (languageResult == TextToSpeech.LANG_MISSING_DATA || languageResult == TextToSpeech.LANG_NOT_SUPPORTED) return;
        textToSpeech.setSpeechRate(rate);
        textToSpeech.speak(text, TextToSpeech.QUEUE_FLUSH, null, "minghui-learning");
    }

    @JavascriptInterface
    public String speechStatus() {
        if (textToSpeechReady) return "ready";
        if (textToSpeechFailed) return "unavailable";
        return "loading";
    }

    public void shutdown() {
        mainHandler.removeCallbacksAndMessages(null);
        textToSpeech.stop();
        textToSpeech.shutdown();
    }

    private static String limit(String value, int maxLength) {
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }
}
