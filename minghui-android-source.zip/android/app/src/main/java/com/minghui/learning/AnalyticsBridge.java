package com.minghui.learning;

import android.content.ContentValues;
import android.database.sqlite.SQLiteDatabase;
import android.webkit.JavascriptInterface;

import org.json.JSONObject;

public final class AnalyticsBridge {
    private final AnalyticsDbHelper helper;

    public AnalyticsBridge(AnalyticsDbHelper helper) {
        this.helper = helper;
    }

    @JavascriptInterface
    public void recordEvent(String rawPayload) {
        try {
            JSONObject payload = new JSONObject(rawPayload);
            String userId = payload.optString("userId", "");
            String eventName = payload.optString("eventName", "");
            if (!userId.matches("[A-Za-z0-9_-]{1,80}") || !eventName.matches("[A-Za-z0-9_.:-]{1,80}")) {
                return;
            }

            JSONObject metadata = payload.optJSONObject("metadata");
            String metadataJson = metadata == null ? "{}" : metadata.toString();
            if (metadataJson.length() > 2000) metadataJson = metadataJson.substring(0, 2000);

            ContentValues values = new ContentValues();
            values.put("user_id", userId);
            values.put("event_name", eventName);
            values.put("page", limit(payload.optString("page", ""), 40));
            values.put("subject_id", limit(payload.optString("subjectId", ""), 40));
            values.put("grade", limit(payload.optString("grade", ""), 20));
            values.put("semester", limit(payload.optString("semester", ""), 20));
            values.put("textbook", limit(payload.optString("textbook", ""), 40));
            values.put("metadata_json", metadataJson);
            SQLiteDatabase database = helper.getWritableDatabase();
            database.insert("user_events", null, values);
        } catch (Exception ignored) {
            // 埋点不能影响学习页面正常使用。
        }
    }

    private static String limit(String value, int maxLength) {
        return value.length() <= maxLength ? value : value.substring(0, maxLength);
    }
}
