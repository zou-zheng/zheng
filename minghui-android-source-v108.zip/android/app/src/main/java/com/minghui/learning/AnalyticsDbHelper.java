package com.minghui.learning;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public final class AnalyticsDbHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "minghui-learning.sqlite";
    private static final int DATABASE_VERSION = 1;

    public AnalyticsDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS user_events (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "user_id TEXT NOT NULL," +
                "event_name TEXT NOT NULL," +
                "page TEXT," +
                "subject_id TEXT," +
                "grade TEXT," +
                "semester TEXT," +
                "textbook TEXT," +
                "metadata_json TEXT NOT NULL DEFAULT '{}'," +
                "created_at TEXT NOT NULL DEFAULT (datetime('now'))" +
                ")");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_events_user_time ON user_events(user_id, created_at)");
        db.execSQL("CREATE INDEX IF NOT EXISTS idx_user_events_name_time ON user_events(event_name, created_at)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 当前版本没有需要迁移的字段，后续版本在这里追加迁移逻辑。
    }
}
