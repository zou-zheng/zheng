plugins {
    id("com.android.application")
}

android {
    namespace = "com.minghui.learning"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.minghui.learning"
        minSdk = 24
        targetSdk = 35
        versionCode = 3
        versionName = "1.0.2"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
