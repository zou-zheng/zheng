plugins {
    id("com.android.application")
}

val stableKeystore = rootProject.file("minghui-release.jks")
val stablePassword = System.getenv("MINGHUI_KEYSTORE_PASSWORD").orEmpty()
val stableAlias = System.getenv("MINGHUI_KEY_ALIAS").orEmpty().ifBlank { "minghui" }
val hasStableSigning = stableKeystore.exists() && stablePassword.isNotBlank()

android {
    namespace = "com.minghui.learning"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.minghui.learning"
        minSdk = 24
        targetSdk = 35
        versionCode = 12
        versionName = "1.0.11"
    }

    signingConfigs {
        if (hasStableSigning) {
            create("stable") {
                storeFile = stableKeystore
                storePassword = stablePassword
                keyAlias = stableAlias
                keyPassword = stablePassword
            }
        }
    }

    buildTypes {
        getByName("debug") {
            if (hasStableSigning) signingConfig = signingConfigs.getByName("stable")
        }
        release {
            isMinifyEnabled = false
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro",
            )
            if (hasStableSigning) signingConfig = signingConfigs.getByName("stable")
        }
    }
}

dependencies {
    implementation("androidx.webkit:webkit:1.11.0")
}
