# 铭惠学习 Android APK

这个目录是由 Vite 前端生成的原生 Android WebView 壳，最低支持 Android 7.0（API 24）。APK 内置当前学习页面，前端的关键操作会通过 `AndroidBridge` 写入 Android SQLite 数据库 `minghui-learning.sqlite`。

AI 联网解题仍需要可访问的后端 `/api/ai/solve`。未配置后端时，页面会自动使用内置演示解析，不影响基础学习、练习、错题本和公式词汇功能。

构建命令：

```bash
./gradlew :app:assembleDebug
```

生成文件：`app/build/outputs/apk/debug/app-debug.apk`

升级说明：保持 `applicationId` 不变并递增 `versionCode`，WebView 的本地学习数据会随覆盖安装保留。前端资料结构版本只用于首次安装和旧演示资料迁移，后续版本不要用它重置用户资料。
